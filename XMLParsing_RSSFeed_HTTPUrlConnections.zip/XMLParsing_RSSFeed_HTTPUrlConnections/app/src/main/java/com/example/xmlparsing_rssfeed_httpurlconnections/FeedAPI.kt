package com.example.xmlparsing_rssfeed_httpurlconnections

import retrofit2.Call
import retrofit2.http.GET

interface FeedAPI {
    @get:GET("blog/feed/")
    val feed: Call<RSS?>?

    companion object {
        const val BASE_URL = "https://www.floretflowers.com/"
    }
}