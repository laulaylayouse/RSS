package com.example.xmlparsing_rssfeed_httpurlconnections

class Data {

    var title: String? = null

    constructor(title: String?) {
        this.title = title
    }
}