package com.example.xmlparsing_rssfeed_httpurlconnections

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.simplexml.SimpleXmlConverterFactory

class MainActivity : AppCompatActivity() {

    lateinit var Recycler_View: RecyclerView
    val list = ArrayList<Data>()
    var call: Call<RSS?>? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        Recycler_View = findViewById(R.id.Recycler_View)
        Recycler_View.adapter = Adapter(list)
        Recycler_View.layoutManager = LinearLayoutManager(this)

        val retrofit = Retrofit.Builder()
            .baseUrl("https://www.floretflowers.com/")
            .addConverterFactory(SimpleXmlConverterFactory.create())
            .build()

        val feedAPI = retrofit.create(FeedAPI::class.java)
        call = feedAPI.feed
        call!!.clone().enqueue(object : Callback<RSS?> {
            override fun onResponse(call: Call<RSS?>, response: Response<RSS?>) {

                val items = response.body()!!.channel!!.item
                for (i in items!!) {

                    var title=i.title.toString()
                    list.add(Data(title))
                    Recycler_View.adapter!!.notifyDataSetChanged()
                }

            }

            override fun onFailure(call: Call<RSS?>, t: Throwable) {

                Toast.makeText(this@MainActivity, "Error!!", Toast.LENGTH_SHORT).show()
            }
        })
    }

}